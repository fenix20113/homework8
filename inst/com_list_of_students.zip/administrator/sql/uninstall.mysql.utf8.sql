DROP TABLE IF EXISTS `#__list_of_students_`;
